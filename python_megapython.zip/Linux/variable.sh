a=4
b=8
echo $a
echo $b
echo $[$a + $b]
