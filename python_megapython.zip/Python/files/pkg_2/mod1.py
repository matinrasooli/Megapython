from pkg_2 import A
print(A)

def add(a, b):
    return a + b

class Foo:
    pass
