print(f'Invoking __init__.py for {__name__}')
A = ['item_1', 'item_2', 'item_3']

__all__ = ['mod1', 'mod2']
