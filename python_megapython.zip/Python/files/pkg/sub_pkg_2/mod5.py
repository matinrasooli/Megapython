from .. import sub_pkg_1
print(sub_pkg_1)

from ..sub_pkg_1.mod3 import sub_foo
sub_foo()
