__all__ = ['foo']

def foo():
    print('[mod1] foo()')

class Foo:
    pass
