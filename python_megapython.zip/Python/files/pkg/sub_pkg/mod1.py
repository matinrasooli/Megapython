def sub_foo():
    print('[mod1] foo()')

class SubFoo:
    pass
