def sub_bar():
    print('[mod2.py] baz()')

class SubBar:
    pass

from pkg.sub_pkg.mod1 import sub_foo
sub_foo()
